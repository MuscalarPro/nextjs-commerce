"use client";

import Image from "next/image";

type GalleryItem = { src: string; altText: string };

function isVideo(src: string) {
  return /\.(mp4|webm|mov|m4v)$/i.test(src);
}

export function Gallery({ images }: { images: GalleryItem[] }) {
  if (!images || images.length === 0) {
    return null;
  }

  return (
    <div className="w-full mt-20">
      {/* Mobile: horizontal media slider */}
      <div className="flex gap-4 overflow-x-auto pb-4 md:hidden snap-x snap-mandatory scrollbar-hide -mx-4 px-2">
        {images.map((image, index) => (
          <div
            key={image.src + index}
            className="relative flex-none w-[88%] overflow-hidden rounded-lg aspect-[3/4] snap-center"
          >
            {isVideo(image.src) ? (
              <video
                autoPlay
                loop
                muted
                playsInline
                className="h-full w-full object-cover"
              >
                <source src={image.src} />
              </video>
            ) : (
              <Image
                className="h-full w-full object-cover transition-transform duration-500"
                fill
                sizes="90vw"
                alt={image.altText}
                src={image.src}
                priority={index === 0}
              />
            )}
          </div>
        ))}
      </div>

      {/* Mobile: infinite marquee text below gallery */}
      <div className="md:hidden mt-6">
        <div className="overflow-hidden">
          <div className="flex w-[200%] animate-marquee whitespace-nowrap text-xs tracking-wide uppercase [will-change:transform]">
            <span className="flex items-center pr-8">
              <span className="font-semibold text-black uppercase">
                #1 Doctor Recommended
              </span>
              <span className="mx-3 text-neutral-400">•</span>
              <span className="text-neutral-500">MUSCLESPAN BRAND</span>
            </span>
            <span className="flex items-center pr-8">
              <span className="font-semibold text-black uppercase">
                #1 Doctor Recommended
              </span>
              <span className="mx-3 text-neutral-400">•</span>
              <span className="text-neutral-500">MUSCLESPAN BRAND</span>
            </span>
          </div>
        </div>
      </div>

      {/* Desktop / larger screens: masonry-style 2-column gallery */}
      <div className="hidden md:grid md:grid-cols-2 md:gap-6">
        {images.map((image, index) => {
          const baseAspectClass =
            index === 0 || index === 1 ? "aspect-[4/5]" : "aspect-[3/4]";

          return (
            <div
              key={image.src + index}
              className={`relative w-full ${baseAspectClass}`}
            >
              {isVideo(image.src) ? (
                <video
                  autoPlay
                  loop
                  muted
                  playsInline
                  className="h-full w-full rounded-md object-contain"
                >
                  <source src={image.src} />
                </video>
              ) : (
                <Image
                  className="h-full w-full object-contain transition-transform duration-700 rounded-md"
                  fill
                  sizes="(min-width: 1024px) 50vw, 100vw"
                  alt={image.altText}
                  src={image.src}
                  priority={index <= 1}
                />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
