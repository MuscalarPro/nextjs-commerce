
export type Patent = {
  id: string;
  number: string;
  title: string;
  filingDate: string;
  status: string;
  abstract: string;
};
